from django.contrib import admin

from .models import Appoinment,Contact_doc

# Register your models here.
admin.site.register(Appoinment)
admin.site.register(Contact_doc)